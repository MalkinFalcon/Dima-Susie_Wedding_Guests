# Handoff: "Find Your Seat" v2 — Dima & Susie Wedding

## Overview
Redesigned mobile-first seat-finder for the wedding QR page. Guests type their name,
tap it, and a staged reveal (velvet curtains → live "searching" camera → slow dive →
chair pull-out ignite → banner) shows them their table and seat.

## About the design file
Unlike a normal design handoff, `index.html` in this folder is **not a mock — it is a
production-ready, self-contained replacement** for `seating/index.html` in the repo
`MalkinFalcon/Dima-Susie_Wedding_Guests` (branch `main`). Same architecture as the
current live file: single HTML, vanilla JS, no build step, Google Fonts only, reads
`seating-data.json` beside it (falls back to the inline `#seating-inline` JSON block —
currently demo data; the repo's real JSON wins at runtime).

## Instruction for Claude Code
1. Replace `seating/index.html` with this file (also mirrored at root `lookup.html` if
   that duplicate is still wanted).
2. Verify `seating/seating-data.json` loads (the fetch is cache-busted). The inline
   fallback block can be refreshed with real data or left as-is.
3. Keep IDs intact: seats render as `<g id="seat-<guestId>" class="chair">`; tables as
   `.table[data-t="<tableId>"]`. All reveal logic keys off these.
4. Test on a phone: type → tap name → full reveal → pinch/drag.

## Integration hooks (built and waiting)
- **Custom per-party messages**: define `window.CUSTOM_MESSAGES = { "<groupId>": "msg", ... }`
  (label strings like `"Dima, Susie"` also work as keys). Message appears in the banner
  under the location line (`#b-msg`), hidden when empty.
- **Dynamic music per party**: the card tap calls `reveal(party)` — key off
  `party.groupId` / `party.category` there, or replace `audio.startWaltz()`.
  Audio module is at the bottom of the file (`const audio = ...`), WebAudio, no assets.
- **Animated GIF pointing at the search box**: mount point is `.search-box`
  (position:relative context is `.search-inner`). Hide it once `body.searching` is set
  (class added on input focus).

## Key behaviours (v2 changes vs live)
- Keyboard-safe search: `interactive-widget=resizes-content` + `visualViewport` resize
  keeps input and results visible above the keyboard.
- Typing shows gold hint "Tap your name below ↓ · Нажмите на своё имя" (`.search-hint.tap`).
- Reveal sequence: curtains (~0.9s) → centred "Finding your seat…" card with spinning
  ring (`#seeking`) while the camera hops 3 random room areas (950ms each, easeInOut)
  → 2.1s dive to the party → seats ignite (per-seat delay capped: `min(150, 1100/n)` ms)
  → banner slides up → pinch-zoom hint chip (`#zoomhint`, auto-hides 6s).
- Chairs are directional shapes (seat pad + backrest) rotated to face table centre;
  `.glow` pulls the chair out from the table (translateY(10px) scale(1.18)) with pulsing
  gold halo. Spotlight pool (`#spot`) fades in under the party.
- Location line uses TABLE centres (not seat centroid): x <300 Left / >700 Right /
  else Centre; y <430 near stage / <950 beside dance floor / <1180 below dance floor /
  else rear of room.

## Design tokens
Palette (CSS vars in `:root`): void #160709, floor #2e1016, claret #5c1a26,
burgundy #7a2230, velvet #8a2f3d, rose #d09a94, gold #c9a557, gold-bright #f2d692,
gold-dark #8f6f2e, cream #f6ecd4, wood #7a4b28/#96603a/#4c2c16.
Type: Cormorant Garamond (display/serif), Inter (UI). Hit targets ≥44px.
Room canvas: 1000×1600 SVG, built at runtime from the data file.

## Files
- `index.html` — the complete v2 page (drop-in for `seating/index.html`).
